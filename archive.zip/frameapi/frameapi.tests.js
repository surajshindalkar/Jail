/**
 * Frame API, Test Suite
 ' @todo: better test cases for setContextMenu Method (section: ContextMenu)
 */
describe('Frame API', function() {
         var require = cordova.require,
         define  =  cordova.define;
         
         it("should exist", function() {
            expect( require("cordova/plugin/FrameAPI") ).toBeDefined();
            });
         
         
         describe("setTitle", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").setTitle ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").setTitle == "function" ).toBe(true);
                     });
                  
                  it("try setting frame title to \"Cordova TestSuite Title\" ", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     var title = "Cordova TestSuite Title";
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.setTitle(title, complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  it("unset title", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     var title = "";
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.setTitle(title, complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  });
         
         describe("disableSidebar", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").disableSidebar ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").disableSidebar == "function" ).toBe(true);
                     });
                  
                  it("try enable disableSidebar", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    frame.enableSidebar(function(){});
                                                                    });
                     
                     runs(function () {
                          frame.disableSidebar(complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  });
         
         describe("enableSidebar", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").enableSidebar ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").enableSidebar == "function" ).toBe(true);
                     });
                  
                  it("try enable enableSidebar", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.enableSidebar(complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  });
         
         describe("Preferences", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").setPreference ).toBeDefined();
                     expect( require("cordova/plugin/FrameAPI").setGlobalPreference ).toBeDefined();
                     expect( require("cordova/plugin/FrameAPI").getPreference ).toBeDefined();
                     expect( require("cordova/plugin/FrameAPI").getGlobalPreference ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").setPreference == "function" ).toBe(true);
                     expect( typeof require("cordova/plugin/FrameAPI").setGlobalPreference == "function" ).toBe(true);
                     expect( typeof require("cordova/plugin/FrameAPI").getPreference == "function" ).toBe(true);
                     expect( typeof require("cordova/plugin/FrameAPI").getGlobalPreference == "function" ).toBe(true);
                     });
                  
                  it("try set variable test", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.setPreference( "test", "test", complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  it("try get variable test", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    expect(success).toBeDefined();
                                                                    expect(success.value).toBeDefined();
                                                                    expect(success.value).toBe("test");
                                                                    });
                     
                     runs(function () {
                          frame.getPreference( "test", complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  it("try set global variable test", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.setGlobalPreference( "test", "test", complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  it("try get global variable test", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    expect(success).toBeDefined();
                                                                    expect(success.value).toBeDefined();
                                                                    expect(success.value).toBe("test");
                                                                    });
                     
                     runs(function () {
                          frame.getGlobalPreference( "test", complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  });
         
         
         describe("ContextMenu", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").setContextMenu ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").setContextMenu == "function" ).toBe(true);
                     });
                  
                  it("set context menu", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    expect(success).toBeDefined();
                                                                    });
                     
                     runs(function () {
                          frame.setContextMenu( [
                                                 { id: "test1", label: "Test Context Menu 1" },
                                                 { id: "test2", label: "Test Context Menu 2" }
                                                 ], complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  it("unset context menu", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    expect(success).toBeDefined();
                                                                    });
                     runs(function () {
                          frame.setContextMenu([], complete);
                          });
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  });
         
         
         describe("hideBar", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").hideBar ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").hideBar == "function" ).toBe(true);
                     });
                  
                  it("hideBar", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    expect(success).toBeDefined();
                                                                    });
                     
                     runs(function () {
                          frame.hideBar( complete);
                          });
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  });
         
         describe("showBar", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").showBar ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").showBar == "function" ).toBe(true);
                     });
                  
                  it("showBar", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    expect(success).toBeDefined();
                                                                    });
                     
                     runs(function () {
                          frame.showBar( complete);
                          });
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  });
         
         
         
         describe("enableUpIcon", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").enableUpIcon ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").enableUpIcon == "function" ).toBe(true);
                     });
                  
                  it("enableUpIcon", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    expect(success).toBeDefined();
                                                                    });
                     
                     runs(function () {
                          frame.enableUpIcon( complete);
                          });
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  });
         
         describe("disableUpIcon", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").disableUpIcon ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").disableUpIcon == "function" ).toBe(true);
                     });
                  
                  it("disableUpIcon", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    expect(success).toBeDefined();
                                                                    });
                     
                     runs(function () {
                          frame.disableUpIcon( complete);
                          });
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     
                     });
                  
                  });
         
         
         describe("setActionItems", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").setActionItems ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").setActionItems == "function" ).toBe(true);
                     });
                  
                  it("setActionItems", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    expect(success).toBeDefined();
                                                                    });
                     
                     runs(function () {
                          frame.setActionItems( [
                                                 { "id": "test1", "label": "Test 1", "icon": "left.png" },
                                                 { "id": "test2", "label": "Test 2", "icon": "" }
                                                 ], complete);
                          });
                     
                     });
                  
                  it("unsetActionItems", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    expect(success).toBeDefined();
                                                                    });
                     
                     runs(function () {
                          frame.setActionItems( [], complete);
                          });
                     
                     });
                  
                  });
         
         
         describe("getVersion", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").getVersion ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").getVersion == "function" ).toBe(true);
                     });
                  
                  it("getVersion", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    console.log( JSON.stringify(success) );
                                                                    expect(error).toBe(null);
                                                                    expect(success).toBeDefined();
                                                                    expect(success.rtversion).toBeDefined();
                                                                    expect(success.APIversion).toBeDefined();
                                                                    });
                     
                     runs(function () {
                          frame.getVersion( complete);
                          });
                     
                     });
                  
                  });
         
         describe("isPassValid", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").isPassValid ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").isPassValid == "function" ).toBe(true);
                     });
                  
                  it("try setting Password to \"Eggs\" ", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     var title = "Eggs";
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.isPassValid(title, complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  
                  
                  });
         
         describe("downloadFile", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").downloadFile ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").downloadFile == "function" ).toBe(true);
                     });
                  
                  it("try downloading some file", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     var title = "http://cb.vu/unixtoolbox.pdf";
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.downloadFile(title, complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  
                  
                  });
         
         describe("encryptFile", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").encryptFile ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").encryptFile == "function" ).toBe(true);
                     });
                  
                  it("encrypts file downloaded in previous test", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     var title = "unixtoolbox.pdf";
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.encryptFile(title, complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  
                  
                  });
         
         describe("decryptFile", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").decryptFile ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").decryptFile == "function" ).toBe(true);
                     });
                  
                  it("decrypts file downloaded in previous test", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     var title = "encrypted_unixtoolbox.pdf";
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.decryptFile(title, complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  
                  
                  });
         
         describe("resetSecret", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").resetSecret ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").resetSecret == "function" ).toBe(true);
                     });
                  
                  it("resets the set secret", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     //var title = "encrypted_unixtoolbox.pdf";
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.resetSecret( complete);
                          });
                     
                     waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  
                  
                  });

          describe("clearMenuItems", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").clearMenuItems ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").clearMenuItems == "function" ).toBe(true);
                     });
                  
                  it("clears menu Items", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     //var title = "encrypted_unixtoolbox.pdf";
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.clearMenuItems( complete);
                          });
                     
                     // waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  
                  
                  });

          describe("addMenuItems", function() {
                  
                  it("should exist", function() {
                     expect( require("cordova/plugin/FrameAPI").addMenuItems ).toBeDefined();
                     expect( typeof require("cordova/plugin/FrameAPI").addMenuItems == "function" ).toBe(true);
                     });
                  
                  it("adds menu Items", function() {
                     var frame = require("cordova/plugin/FrameAPI");
                     var menuItems =  [

    {"flyoutmenu": true, "caption": "caption of menu 1", "url": "www/index.html", "caption_de": "DEUTSCHE BESCHR", "caption_fr": "le truc francais" },

    {"flyoutmenu": true, "caption": "caption of menu 2", "url": "xyz/index.html", "caption_de": "das eben auch", "caption_fr": "celui aussi" },

    {"flyoutmenu": true, "caption": "caption of menu 3", "url": "abc/index.html", "caption_de": "und das auch", "caption_fr": "et quoi encore" },

   ];
                     
                     var complete = jasmine.createSpy().andCallFake(function(error, success){
                                                                    expect(error).toBe(null);
                                                                    });
                     
                     runs(function () {
                          frame.addMenuItems(menuItems, complete);
                          });
                     
                     // waitsFor(function () { return complete.wasCalled; }, "no callbacks are recieved", TEST_TIMEOUT);
                     });
                  
                  
                  
                  });
         
         });