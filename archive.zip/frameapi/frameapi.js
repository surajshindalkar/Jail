;(function(cordova, undefined){
  
  var require = cordova.require,
      define  =  cordova.define;
  
  /**
   * Frame API, For Documentation and Specification see at: https://wiki.onewebuxp.allianz/confluence/display/AWY/Frame
   */
  define("cordova/plugin/FrameAPI", function(require, exports, module){
    
    var exec = require('cordova/exec'),
        _module_name = "FrameAPI";
    
    function parseArguments( options, successCallback, errorCallback, completeCallback ){
      if( errorCallback == undefined && completeCallback == undefined && successCallback != undefined ){
        completeCallback = successCallback;
        successCallback = undefined;
      }
      
      function complete(error, success){
        //if( !options.disableJSONAutomatic ){
        //  if( error != undefined && error.substr != undefined && error.substr(0,1) == "{" ) error = JSON.parse(error);
        //  if( success != undefined && success.substr != undefined && success.substr(0,1) == "{" ) success = JSON.parse(success);
        //}
        if( successCallback != undefined && error == null ) successCallback(success);
        if( errorCallback != undefined && error !== null ) errorCallback(error);
        if( completeCallback != undefined ) completeCallback(error, success);
      };
      
      var opt = {
        kwargs: {},
        args: [],
        success: function(data){ complete(null, data); },
        error: function(data){ complete(data, null); }
      };
      if( !options.propertyIsEnumerable || !options.propertyIsEnumerable() ){
        opt.args.push( options );
      } else {
        for( var k in options ){
          if( typeof(k) == "number" ){
            opt.args.push(options[k]);
          } else {
            opt.kwargs[k] = options[k];
          }
        }
      }
      return opt;
    };
    
    module.exports = {
      
      /**
       * parseArguments
       * @name: require("cordova/plugin/FrameAPI").parseArguments
       * @param {Object|Array|DOMString|Number} options
       * @param {Function} successCallback, optional
       * @param {Function} errorCallback, optional
       * @param {Function} completeCallback, optional
       * @return {Object}
       */
      parseArguments: parseArguments,
      
      /**
       * removeFilePrefix
       * @name: require("cordova/plugin/FrameAPI").removeFilePrefix
       * @param {DOMString} path
       * @return {DOMString}
       */
      removeFilePrefix: function(path){
        path = String(path || "");
        if( path.substr(0, 5) == "file:" ){
          var i=0,z,l=path.length;
          for(z=5;z<l;z++){
            if(path[z] == "/") i++;
            else break;
          }
          path = path.substr(5+(i-1), path.length);
        }
        return path;
      },
      
      /**
       * setTitle
       * @name: require("cordova/plugin/FrameAPI").setTitle
       * @param {DomString} title
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      setTitle: function( title, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( title, successCallback, errorCallback, completeCallback );
        title = _opt.kwargs.title || _opt.args[0];
        if( !title ) title = "";
        _opt.args = [ { title: title } ];
        exec( _opt.success, _opt.error, _module_name, "setTitle", _opt.args );
        return module.exports;
      },
      
      /**
       * enableSidebar
       * @name: require("cordova/plugin/FrameAPI").enableSidebar
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      enableSidebar: function( successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {}, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "enableSidebar", _opt.args );
        return module.exports;
      },
      
      /**
       * disableSidebar
       * @name: require("cordova/plugin/FrameAPI").disableSidebar
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      disableSidebar: function( successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {}, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "disableSidebar", _opt.args );
        return module.exports;
      },
      
      /**
       * setContextMenu
       * @name: require("cordova/plugin/FrameAPI").setContextMenu
       * @param: {Array} menu, eg.: [ {"id": "menu1", "label": "Menu 1"}, {"id": "menu2", "label": "Menu 2"} ]
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      setContextMenu: function( menu, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {
          menu: menu || []
        }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "setContextMenu", _opt.args );
        return module.exports;
      },
      
      /**
       * setPreference
       * @name: require("cordova/plugin/FrameAPI").setPreference
       * @param: {DOMString} key
       * @param: {DOMString} value
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      setPreference: function( key, value, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {
          id: key,
          value: value
        }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "setPreference", _opt.args );
        return module.exports;
      },
      
      /**
       * getPreference
       * @name: require("cordova/plugin/FrameAPI").getPreference
       * @param: {DOMString} key
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      getPreference: function( key, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {
          id: key,
          disableJSONAutomatic: true
        }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "getPreference", _opt.args );
        return module.exports;
      },
      
      /**
       * setGlobalPreference
       * @name: require("cordova/plugin/FrameAPI").setGlobalPreference
       * @param: {DOMString} key
       * @param: {DOMString} value
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      setGlobalPreference: function( key, value, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {
          id: key,
          value: value
        }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "setGlobalPreference", _opt.args );
        return module.exports;
      },
      
      /**
       * getGlobalPreference
       * @name: require("cordova/plugin/FrameAPI").getGlobalPreference
       * @param: {DOMString} key
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      getGlobalPreference: function( key, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {
          id: key,
          disableJSONAutomatic: true
        }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "getGlobalPreference", _opt.args );
        return module.exports;
      },
      
      
      /**
       * showBar
       * @name: require("cordova/plugin/FrameAPI").showBar
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      showBar: function( successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {}, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "showBar", _opt.args );
        return module.exports;
      },
      
      /**
       * hideBar
       * @name: require("cordova/plugin/FrameAPI").hideBar
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      hideBar: function( successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {}, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "hideBar", _opt.args );
        return module.exports;
      },
      
      /**
       * enableUpIcon
       * @name: require("cordova/plugin/FrameAPI").enableUpIcon
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      enableUpIcon: function( successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {}, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "enableUpIcon", _opt.args );
        return module.exports;
      },
      
      /**
       * disableUpIcon
       * @name: require("cordova/plugin/FrameAPI").disableUpIcon
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      disableUpIcon: function( successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {}, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "disableUpIcon", _opt.args );
        return module.exports;
      },
      
      /**
       * setHomeIcon
       * @param: {DOMString} key
       * @name: require("cordova/plugin/FrameAPI").setHomeIcon
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      setHomeIcon: function( iconpath, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {
          iconpath: iconpath
        }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "setHomeIcon", _opt.args );
        return module.exports;
      },
      
      /**
       * setActionItems
       * @param: {Array} {DOMString} actionitems, example: [ { "id": "icon1.png": "label": "do this"} ]
       * @name: require("cordova/plugin/FrameAPI").setHomeIcon
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      setActionItems: function( actionitems, successCallback, errorCallback, completeCallback){
        for( var i=0, l = actionitems.length; i < l; i++  ){
          if( !actionitems[i].id ) actionitems[i].id = String(i);
          if( !actionitems[i].icon ) actionitems[i].icon = "";
          if( !actionitems[i].label ) actionitems[i].label = "";
        }
        var _opt = parseArguments( {
          actionitems: actionitems
        }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "setActionItems", _opt.args );
        return module.exports;
      },
      
      /**
       * getVersion
       * @name: require("cordova/plugin/FrameAPI").setHomeIcon
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      getVersion: function( successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( { }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "getVersion", _opt.args );
        return module.exports;
      },
      
       /**
       * downloadFile
       * @param: {DOMString} url
       * @name: require("cordova/plugin/FrameAPI").downloadFile
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      downloadFile: function( url, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {
          url: url
        }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "downloadFile", _opt.args );
        return module.exports;
      },

       /**
       * decryptFile
       * @param: {DOMString} filename
       * @name: require("cordova/plugin/FrameAPI").decryptFile
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      decryptFile: function( filename, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {
          filename: filename
        }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "decryptFile", _opt.args );
        return module.exports;
      },

        /**
       * encryptFile
       * @param: {DOMString} filename
       * @name: require("cordova/plugin/FrameAPI").decryptFile
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      encryptFile: function( filename, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {
          filename: filename
        }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "encryptFile", _opt.args );
        return module.exports;
      },

        /**
       * isPassValid
       * @param: {DOMString} pass
       * @name: require("cordova/plugin/FrameAPI").isPassValid
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      isPassValid: function( pass, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {
          pass: pass
        }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "isPassValid", _opt.args );
        return module.exports;
      },

        /**
       * resetSecret
       * @name: require("cordova/plugin/FrameAPI").resetSecret
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      resetSecret: function(successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {}, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "resetSecret", _opt.args );
        return module.exports;
      },

      /**
       * clearMenuItems
       * @name: require("cordova/plugin/FrameAPI").clearMenuItems
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      clearMenuItems: function(successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( {}, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "clearMenuItems", _opt.args );
        return module.exports;
      },

      /**
       * addMenuItems
       * @name: require("cordova/plugin/FrameAPI").addMenuItems
       * @param: {Array} menu, eg.: [  { "flyoutmenu": true, "caption": "caption of menu 2", "url": "xyz/index.html", "caption_de": "das eben auch", "caption_fr": "celui aussi" },
       *{"flyoutmenu": true, "caption": "caption of menu 3", "url": "abc/index.html", "caption_de": "und das auch", "caption_fr": "et quoi encore" }, ]
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      addMenuItems: function( menu, successCallback, errorCallback, completeCallback){
        var _opt = parseArguments(menu, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "addMenuItems", _opt.args[0] );
        return module.exports;
      },

      /**
       * getDataPath
       * @name: require("cordova/plugin/FrameAPI").addMenuItems
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      getDataPath: function(successCallback, errorCallback, completeCallback){
        var _opt = parseArguments({}, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "getDataPath", _opt.args );
        return module.exports;
      },
      
      /**
       * _dev_refresh_settings
       * @name: require("cordova/plugin/FrameAPI")._dev_refresh_settings
       * @return {Object} require("cordova/plugin/FrameAPI")
       */
      _dev_refresh_settings: function( successCallback, errorCallback, completeCallback){
        var _opt = parseArguments( { }, successCallback, errorCallback, completeCallback );
        exec( _opt.success, _opt.error, _module_name, "_dev_refresh_settings", _opt.args );
        return module.exports;
      }
      
    };
    
  });
  
})(cordova);